
# SubscriptionUpdate


## Properties

Name | Type
------------ | -------------
`name` | string
`url` | string
`eventFilter` | string

## Example

```typescript
import type { SubscriptionUpdate } from '@philiprehberger/webhook-relay-client'

// TODO: Update the object below with actual values
const example = {
  "name": null,
  "url": null,
  "eventFilter": null,
} satisfies SubscriptionUpdate

console.log(example)

// Convert the instance to a JSON string
const exampleJSON: string = JSON.stringify(example)
console.log(exampleJSON)

// Parse the JSON string back to an object
const exampleParsed = JSON.parse(exampleJSON) as SubscriptionUpdate
console.log(exampleParsed)
```

[[Back to top]](#) [[Back to API list]](../README.md#api-endpoints) [[Back to Model list]](../README.md#models) [[Back to README]](../README.md)


